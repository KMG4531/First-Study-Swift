import Cocoa

var str = "Hello, Swift"
print(str)


print(str)

var sum = 0
for i in 1...10{
    sum += i
}
print(sum)
